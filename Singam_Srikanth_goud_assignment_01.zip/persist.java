import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class persist {

	
			 
	 private static final String filepath="E:\\dxc\\sample\\src\\\\Employee.java";
		 
		    public static void main(String args[]) {
		 
		        persist objectIO = new persist();
		 
		        Employee  emp= new Employee("jagadish",45,"bangalore",100000);
		        objectIO.WriteObjectToFile(emp);
		    }
		 
		    public void WriteObjectToFile(Object serObj) {
		 
		        try {
		 
		          
					
					FileOutputStream fileOut = new FileOutputStream(filepath);
		            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
		            objectOut.writeObject(serObj);
		            objectOut.close();
		            System.out.println("The Object  was succesfully written to a file");
		 
		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		    }
		

	}

