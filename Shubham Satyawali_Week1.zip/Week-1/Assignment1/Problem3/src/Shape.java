abstract public class Shape {
	
	abstract public double calcArea();
}

class Square extends Shape{
	private double side;
	
	Square(double side){
		this.side = side;
	}
	
	@Override
	public double calcArea() {
		// TODO Auto-generated method stub
		return side*side;
	}
	
}

class Circle extends Shape{
	private double rad;
	
	Circle(double rad){
		this.rad = rad;
	}
	@Override
	public double calcArea() {
		// TODO Auto-generated method stub
		return 3.14*rad*rad;
	}
	
}

class Triangle extends Shape{
	private double base, height;
	
	Triangle(double b, double h){
		base = b;
		height = h;
	}
	@Override
	public double calcArea() {
		// TODO Auto-generated method stub
		return 0.5*base*height;
	}
	
}
