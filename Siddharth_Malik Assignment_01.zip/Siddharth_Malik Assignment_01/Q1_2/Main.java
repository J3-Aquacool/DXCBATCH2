
 abstract class Batsmen  {

		int avg;
		String name;
		int age;
	
		Batsmen(String name,int age,int avg){
			this.name=name;
			this.age=age;
			this.avg=avg;
		}
}

 abstract class Bowler  {

	int eco;
	String name;
	int age;
	Bowler(String name,int age,int eco){
		this.name=name;
		this.age=age;
		this.eco=eco;
	}
}
 abstract class WicketKeeper  {

	int stumps;
	String name;
	int age;
	WicketKeeper(String name,int age,int stumps){
		this.name=name;
		this.age=age;
		this.stumps=stumps;
	}
}

  abstract class AllRounder  {

		int avg;
		int eco;
		String name;
		int age;
		AllRounder(String name,int age,int avg,int eco){
			this.name=name;
			this.age=age;
			this.avg=avg;
			this.eco=eco;
		}
		
}
   class Mens { //Men's Cricket Team
		
		Batsmen Bat;
		Bowler Bowl;
		WicketKeeper WK;
		AllRounder AR;
		public Mens(Batsmen bat, Bowler bowl, WicketKeeper wK, AllRounder aR) {
			super();
			Bat = bat;
			Bowl = bowl;
			WK = wK;
			AR = aR;
		}
		
		
}
   class Womens {	//Women's Cricket Team
		
		Batsmen Bat;
		Bowler Bowl;
		WicketKeeper WK;
		AllRounder AR;
		
		public Womens(Batsmen bat, Bowler bowl, WicketKeeper wK, AllRounder aR) {
			super();
			Bat = bat;
			Bowl = bowl;
			WK = wK;
			AR = aR;
		}
	
		
}


public class Main {  //DXC Cricket.
	
		
}
