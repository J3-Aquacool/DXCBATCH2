import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Persistt {

	
			 
	 private static final String filepath="C:\\Users\\prava\\eclipse-workspace\\Day3demo\\src\\Emplooy.java";
		 
		    public static void main(String args[]) {
		 
		        Persistt objectIO = new Persistt();
		 
		        Emplooy  emp= new Emplooy("pravalika",21,"warangal",1500);
		        objectIO.WriteObjectToFile(emp);
		    }
		 
		    public void WriteObjectToFile(Object serObj) {
		 
		        try {
		 
		          
					
					FileOutputStream fileOut = new FileOutputStream(filepath);
		            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
		            objectOut.writeObject(serObj);
		            objectOut.close();
		            System.out.println("The Object  was succesfully written to a file");
		 
		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		    }
		

	}