public class Trainee {
	protected String trname;
	int trid;
	int trage;
	String trdept;

	Trainee(String trname, int trid, int trage, String trdept){
	this.trname = trname;
	this.trid = trid;
	this.trage= trage;
	this.trdept = trdept;
	}

	void printall(Course[] carr){
		System.out.println("Trainee's name is: "+trname);
		System.out.println(trname+"'s ID: "+trid);
		System.out.println(trname+"'s age is: "+trage);
		System.out.println(trname+"'s Department is:" +trdept);
		System.out.print(trname+" is enrolled in ");
		for (Course c : carr) {
			System.out.print(c.cname + " ");
		}
	}
}
