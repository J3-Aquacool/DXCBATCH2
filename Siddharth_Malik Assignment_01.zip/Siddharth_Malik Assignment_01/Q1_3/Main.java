
public class Main {

	
	public static void main(String[] args) {
		Shape C1 = new Circle(5);
		C1.area();
		
		Shape S1 = new Square(5);
		S1.area();
		
		Shape T1 = new Triangle(10,5);
		T1.area();
	}
}