class Family
{
	String fmember; // Instance Member
	
	void internalFamily()
	{
		String intf_member;
		fmember="Family Member";
		
		intf1_member="Iam Famiy2Member";
	}
	
	void internalFamily1()
	{
		String intf1_member;
		
		intf_member="Iam Family 1";
		
		fmember="I am Visitin Family2 Members";
	}
	
	
	
}




public class MemberScope {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
