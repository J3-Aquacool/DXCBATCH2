import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CricketerInformation {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      ArrayList<Cricketer> al=new ArrayList<Cricketer>();
      
      al.add(new Cricketer("Raina",4));
      al.add(new Cricketer("Virat",3));
      al.add(new Cricketer("Rohit",1));
      al.add(new Cricketer("Sehwag",2));
      al.add(new Cricketer("Dhoni",5));
      al.add(new Cricketer("Gambhir",6));
      al.add(new Cricketer("Jaddu",7));
      al.add(new Cricketer("Bhumra",9));
      al.add(new Cricketer("Bhuvi",8));
      al.add(new Cricketer("Sundar",10));
      
      
      /*Iterator <Cricketer> it=al.iterator();*/
      ComparebybatsmanName bn = new ComparebybatsmanName();
      Collections.sort(al, bn);
      for (Cricketer cricketer: al)
          System.out.println(cricketer.getBatsmanName() + " " + cricketer.getBattingPosition());
     System.out.println("*****");
     Comparebattingposition bp = new Comparebattingposition();
      Collections.sort(al,bp );
      for (Cricketer cricketer: al)
          System.out.println(cricketer.getBatsmanName() + " " + cricketer.getBattingPosition());
     
	}

}
