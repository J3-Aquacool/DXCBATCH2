public class Units {
	
	protected String uname;
	private int numTopics;
	private int unum;
	
	Units(String uname, int numTopics, int unum) {
		this.uname = uname;
		this.numTopics = numTopics;
		this.unum = unum;
	}
	
	@Override
	public String toString() {
		return "Unit [Name= " + uname + ", Topics included= " + numTopics + ", Unit nuber = " + unum + "]";
	}
	
	public void printTopics(Topics[] toarr) {
		System.out.print("Unit "+uname+" contains topics like: ");
		for(Topics to: toarr) {
			System.out.print(to.toname+ " ");
		}
	}
}
