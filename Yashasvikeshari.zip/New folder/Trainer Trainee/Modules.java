
public class Modules {
Modules()
{}
String mname;
int nounits;
int notrainee;
String duration;
Modules(String mname,int nounits,int notrainee,String duration)
{ this.mname=mname;
this.nounits=nounits;
this.notrainee=notrainee;
this.duration=duration;

	}
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public int getNounits() {
	return nounits;
}
public void setNounits(int nounits) {
	this.nounits = nounits;
}
public int getNotrainee() {
	return notrainee;
}
public void setNotrainee(int notrainee) {
	this.notrainee = notrainee;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}

}



public class MainApp
{
	public static void main(String args[])
	{
	Modules m=new Modules();
		m.setMname("Introduction to Java");
		m.setNounits(7);
		m.setNotrainee(22);
		m.setDuration("7days");
		System.out.println(m.getMname());
		System.out.println(m.getNounits());
		System.out.println(m.getNotrainee());
		System.out.println(m.getDuration());
}
}