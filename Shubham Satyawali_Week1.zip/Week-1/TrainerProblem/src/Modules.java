public class Modules {
	
	protected String mName;
	private int numUnits;
	
	Modules(String mName, int numUnits) {
		this.mName = mName;
		this.numUnits = numUnits;
	}
	
	void mdisplay(Units[] uarr) {
		System.out.println("Name of the module: "+mName);
		System.out.println("Number of units in "+mName+" are "+numUnits);
		System.out.print(mName+" contains these modules: ");
		for(Units u: uarr) {
			System.out.print(u.uname+" ");
		}
	}
}
