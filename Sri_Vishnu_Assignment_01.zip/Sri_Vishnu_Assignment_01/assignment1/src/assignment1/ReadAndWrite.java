package assignment1;
 
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException; 
  
class ReadAndWrite { 
   
    public static void main(String[] args) 
    {  
        try { 
  
        	// Creating a FileWriter object to read from a file "demo"
            FileReader readingFile = new FileReader("C:/Users/psvis/Desktop/demo.txt"); 
  
            // Creating a FileWriter object to write into a file "demo1"
            FileWriter writingFile = new FileWriter("C:/Users/psvis/Desktop/demo1.txt"); 
  
        
            String text = ""; 
            int i; 
  
            while ((i = readingFile.read()) != -1) { 
  
                text += (char)i; 
            } 
         
            System.out.println("Displaying the text in file...");
            System.out.println("");
            System.out.println(text); 
            writingFile.write(text); 
  
            readingFile.close(); 
            writingFile.close(); 
  
            // Display message 
            System.out.println("");
            System.out.println( "File content copied to another file."); 
        	} 
   
        catch (IOException e) {
        	
            System.out.println("There is no file..."); 
        } 
    } 
}


