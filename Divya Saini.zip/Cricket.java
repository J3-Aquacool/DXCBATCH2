abstract class CricketTeam
{
	
	public void bowler()
	{
		System.out.println("This is the bowler");
	}
	public void batsmen()
	{
		System.out.println("This is the batsmen");
	}
	public void allrounder()
	{
		System.out.println("These are the allrounders");
	}
	public void wicketkeeper()
	{
		System.out.println("This is the wicketkeeper");
	}	
}
class MenTeam extends CricketTeam
{
	MenTeam()
	{
		System.out.println("This is a mens cricket team");
	}
}
class WomenTeam extends CricketTeam
{
	WomenTeam()
	{
		System.out.println("This is a womens cricket team");
	}	
}

public class Cricket
{
	public static void main(String[] args) 
	{
		System.out.println("This is a cricket team");
		CricketTeam c=new MenTeam();
		System.out.println(c instanceof MenTeam);
		
		c.bowler();
		c.batsmen();
		c.allrounder();
		c.wicketkeeper();
		
		c=new WomenTeam();
		System.out.println(c instanceof WomenTeam);
		
		c.bowler();
		c.batsmen();
		c.allrounder();
		c.wicketkeeper();
	}
}


