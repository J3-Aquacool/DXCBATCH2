package assignment1;

class Course{
	
	Course(){
		
		System.out.println("I am a course.");
	}
	
	void courseFeatures() {
		
		System.out.println("Courses have many modules.");
	}
	
	
}
class Module extends Course{
	
	Module(){
		
		System.out.println("I am a module.");
	}
	
	void moduleFeatures() {
		
		System.out.println("Modules have many units.");
	}
	
	
}
class Unit extends Module{
	
	Unit(){
		
		System.out.println("I am a unit.");
	}
	
	void unitFeatures() {
		
		System.out.println("Units have many topics.");
	}
	
	
}
class Topics extends Unit{
	
	Topics(){
		
		System.out.println("I am a topic.");
	}
	
	void topicFeatures() {
		
		System.out.println("Topics must be learned by the trainee.");
	}
	
	
}

class Trainer extends Topics{
	
	Trainer(){
		super();
		System.out.println("I am a trainer");
	}
	Trainer(String name,String course, String module,String unit,String topic,String name2, String course2){
		
		System.out.println("My name is "+name+".");
		System.out.println("I teach "+course+".");
		System.out.println("Java contains "+module+" Java.");
		System.out.println("Core Java has "+unit+".");
		System.out.println("OOPs has "+topic+".");
		System.out.println("My name is "+name2+".");
		System.out.println("I teach "+course2+".");
		
	}
void trainerFeatures() {
		
		System.out.println("Features of trainer.");
	}
	
}

class Trainee extends Trainer{
	
	Trainee(){
		super("Daniel","Java","Core & Advanced","OOPs","Inheritance","Jack","Python");
		System.out.println("My name is Vishnu and I am a trainee.");
	}
void traineeFeatures() {
		
		System.out.println("I am learning Java.");
	}
}

public class OnlineCourse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Trainee obj = new Trainee();
		obj.traineeFeatures();
		obj.courseFeatures();
		obj.moduleFeatures();
		obj.unitFeatures();
		obj.topicFeatures();

		
	}

}