import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Filerw {
		 public static void main(String args[]) {
			 try {
		 File fobj=new File("classdemo.txt");
		
		 FileWriter fwrite=new FileWriter(fobj);
		 FileReader fread=new FileReader(fobj);
		 //writing in file starts
		 String content="program completed";
		 fwrite.write(content);
		 fwrite.close(); 
		 System.out.println("File wrote successfully");
		 //reading of file gets strted
		 int j;    
         while((j=fread.read())!=-1)    
         System.out.print((char)j);    
         fread.close();
			 }
			 catch (Exception e)
			 {
				 System.out.println(e.getMessage());
			 }

}
}
