
class A    // Object
{
	
	void test()
	{
		
	}
}


class B extends A    // Userdefined
{

	void test1()
	{
		
	}
	
}





public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		B bobj=new B();
		bobj.test1();
		bobj.test();
	
		bobj.toString();

		A aobj=new A();
		aobj.toString();
		
	}

}
