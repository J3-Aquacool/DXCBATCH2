public class Trainer {
	private String tname;
	private int tid;
	private int tage;
	private int maxtrainee;

	Trainer(String tname,int tid, int tage, int maxtrainee){
	this.tname = tname;
	this.tid = tid;
	this.tage = tage;
	this.maxtrainee = maxtrainee;
	}

	void display(Trainee arr[]){
		System.out.println("Name of the trainer is: "+tname);
		System.out.println("Trainer ID is:"+tid);
		System.out.println("Trainer's age is:" +tage);
		System.out.println(tname+" has a capacity of "+ maxtrainee+ " Trainees.");
		System.out.print("Current Trainees are: ");
		for (Trainee t : arr) {
			System.out.print(t.trname + " ");
		}
	}
}
