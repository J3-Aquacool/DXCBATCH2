
public class Unit {

		String Unit;
		Topic T;
		
Unit(){
	
}
		public String getUnit() {
			return Unit;
		}

		public void setUnit(String unit) {
			Unit = unit;
		}
		public Unit(String Unit, Topic T) {
			this.Unit = Unit;
			this.T = T;
		}
		void printDetails() {
			System.out.println(" Name of the unit is: "+Unit);
	System.out.println(T.print());
		}
		String print() {
			return " Name of the unit is: "+Unit+"\n"+T.print();
		}
		@Override
		public String toString() {
			return " Unit [Unit=" + Unit + ", T=" + T + "]";
		}
		
}
