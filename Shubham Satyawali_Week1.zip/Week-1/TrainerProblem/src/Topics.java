public class Topics {
	protected String toname;
	private int numsubtopic;
	
	Topics(){
		toname = null;
		numsubtopic = 0;
	}
	
	void setvalue(String toname, int numsubtopic){
		this.toname = toname;
		this.numsubtopic = numsubtopic;
	}
	
	void getvalue() {
		if(toname == null) {
			System.out.println("No topics defined!!!");
		}
		else {
			System.out.println("Topic Name: "+toname);
			System.out.println("Number of subtopics in "+toname+" is/are: "+numsubtopic);
		}
	}
	
}
