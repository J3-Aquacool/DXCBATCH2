import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Readdemo1 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		BufferedReader br1 = null;
		try {
			String line;
			br1 = new BufferedReader(new FileReader("/home/utkarsh/Development/Java/IOSelfExercise/src/demo1.txt"));
			
			while((line = br1.readLine())!= null) {
				
				System.out.println(line);
				
			}
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			br1.close();
		}
	}

}
