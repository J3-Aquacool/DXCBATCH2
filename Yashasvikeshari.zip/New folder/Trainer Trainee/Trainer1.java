
public class Trainer1
{
	//states
	 
	String name;
	int trid;
	int phoneno;
	String emailid;

	//behaviour
	void conductSessions()
	{
		System.out.println("Trainer is conducting the session");
	}

	String typeofSession()
	{
		return "JavaFullStack";
	}
	static void profile()
	{
		
		System.out.println("My profile is work Full Stack solutions");
	  }

	void briefinfo()
	{
	 	name="Yashi";
		trid=12345;
		phoneno=6376536;
		emailid="gd@gmail.com";
		System.out.println("Name:"+name);
		System.out.println("Trainer id:"+trid);
		System.out.println("Phone number:"+phoneno);
		System.out.println("Email id:"+emailid);
	}	
	
}


public class MainApp
{
	public static void main(String args[])
	{
	Trainer1.profile();
	Trainer1 obj=new Trainer1();
	//obj.profile();//using static we dont need to call it like this
	obj.briefinfo();
