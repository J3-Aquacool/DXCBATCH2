
public class Module {

	
		String Modulename;
		Unit U;
		
		
		public Module(String modulename, Unit u) {
			super();
			Modulename = modulename;
			U = u;
		}


		void printDetails() {
			System.out.println("Module Name is : "+Modulename+U.print());
		}
		String print() {
			return "Module Name is: "+Modulename+"\n"+U.print();
		}


		@Override
		public String toString() {
			return "Module [Modulename=" + Modulename + ", U=" + U;
		}
		
}
