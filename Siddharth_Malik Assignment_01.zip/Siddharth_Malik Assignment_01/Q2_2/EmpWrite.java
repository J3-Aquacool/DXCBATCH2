import java.util.*;
import java.io.*;


 class EmpWrit  {
				int empid;
				String empName;
				String Designation;
			Double Basic;
			Double HRA;
			
			public EmpWrit(int empid, String empName, String designation, Double basic, Double hRA) {
				super();
				this.empid = empid;
				this.empName = empName;
				Designation = designation;
				Basic = basic;
				HRA = hRA;
			}
			public int getEmpid() {
				return empid;
			}
			public void setEmpid(int empid) {
				this.empid = empid;
			}
			public String getEmpName() {
				return empName;
			}
			public void setEmpName(String empName) {
				this.empName = empName;
			}
			public String getDesignation() {
				return Designation;
			}
			public void setDesignation(String designation) {
				Designation = designation;
			}
			public Double getBasic() {
				return Basic;
			}
			public void setBasic(Double basic) {
				Basic = basic;
			}
			public Double getHRA() {
				return HRA;
			}
			public void setHRA(Double hRA) {
				HRA = hRA;
			}
			@Override
			public String toString() {
				return "EmpWrit [empid=" + empid + ", empName=" + empName + ", Designation=" + Designation + ", Basic="
						+ Basic + ", HRA=" + HRA + "]";
			}
		
		 
		
		
}
   public class EmpWrite{
    	public static void main(String[] args) throws IOException {
			EmpWrit E = new EmpWrit(101,"Aman","Manager",708.2,123.1);
			
			E.setEmpName("Aman");
			E.setEmpid(101);
			E.setDesignation("Manager");
			E.setHRA(50.0);
			E.setBasic(101.0);

		
	   			FileOutputStream fos = new FileOutputStream("/Users/harishmalik/Desktop/Output.txt");
	   			ObjectOutputStream oos = new ObjectOutputStream(fos);
	   			oos.writeObject(E.toString());
	   			System.out.println("Done");
	   			oos.close();
	   			fos.close();
	   		
			
	}	
    	
    	
    	
   }
   
   