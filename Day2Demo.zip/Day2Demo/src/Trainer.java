
public class Trainer 
{
// states
// isntance members
	String name;
int trid;
int phone;
String emailid;
// behaviour


// A No-name block will execute when an object of class is created
// This block will get execute the number of times the object is created
{
	System.out.println("Team Members Admisiion Block");
	
}


void conductSessions()
{
	
	System.out.println("Trainer is conduction the Sessions");
	
}

String typeofSessions()
{
	 int ver=8;// local member
	return "JavaFullStack"+ver;
	
}


static void  profile()
{
	
	System.out.println("My Profile is Works Has FullStack Solutionist");
	
}

void briefInfo()
{
	name="Daniel";
	trid=101;
	emailid="daniel@gmail.com";
	phone=1000;
	System.out.println("Name:"+name);
	System.out.println("Id:"+trid);
	System.out.println("email:"+emailid);
	System.out.println("Phone:"+phone);
	
}


}


