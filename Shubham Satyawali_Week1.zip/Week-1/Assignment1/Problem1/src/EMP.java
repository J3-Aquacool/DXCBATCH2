
public class EMP {
	
	protected int EMPID;
	protected String EMPNAME, DESIGNATION ;
	protected double BASIC, HRA;
	
	public EMP(int EMPID, String EMPNAME, String DESIGNATION, double BASIC){
		
		this.EMPID = EMPID;
		this.EMPNAME = EMPNAME;
		this.DESIGNATION = DESIGNATION;
		this.BASIC = BASIC;
	}
	
	public void printDET(){
		
		System.out.println("Emp ID: "+EMPID+"\nEmployee name: "+EMPNAME+"\nDesignation: "+DESIGNATION+"\nBasic Salary: "+BASIC);
		calculateHRA(DESIGNATION, BASIC);
	}
	
	public void calculateHRA(String Des, double bas){
		
		if(Des=="Manager") {
			System.out.println("Calculated HRA: "+0.1*bas+"\n");
		}
		else if(Des == "Officer") {
			System.out.println("Calculated HRA: "+0.12*bas+"\n");
		}
		else if(Des == "Clerk") {
			System.out.println("Calculated HRA: "+0.05*bas+"\n");
		}
		else {
			System.out.println("Error check Designation\n");
		}
		
	}	 
}
