import java.util.Comparator;

public class Comparebattingposition implements Comparator<Cricketer>
		{

			@Override
			public int compare(Cricketer o1, Cricketer o2) {
				// TODO Auto-generated method stub
				if (o1.getBattingPosition() < o2.getBattingPosition()) return -1;
		        if (o1.getBattingPosition() > o2.getBattingPosition()) return 1;
		        else return 0;
			}
			
}