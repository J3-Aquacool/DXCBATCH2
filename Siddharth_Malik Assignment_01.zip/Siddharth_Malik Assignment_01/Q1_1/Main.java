
public class Main {

		public static void main(String[] args) {
			EMP E1=new EMP(101,"Aman","Manager",25000.0);
			E1.HRA();
			E1.printDET();
		}
}
