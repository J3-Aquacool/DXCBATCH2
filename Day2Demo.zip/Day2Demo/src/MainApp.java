
public class MainApp {

	public static void main(String[] args) 
	{
/*// Lets create an Object of Trainer

// Every Object will Hold its own copy of members located @ diferent locations
		
		
Trainer.profile();

// Static methods are independent members of a class
// They do not depend on The Object of a Class
 // Yes we cann acces static members eith obejcts of a class

Trainer obj=new Trainer();
Trainer obj1=new Trainer();
	obj.briefInfo();
		
		//String type=obj.typeofSessions();
		
	System.out.println("Type of Training:"+obj.typeofSessions()); // if the value is not required for further usage we can use this
	
		
		obj.conductSessions();
		
		
//		new Trainer();// instance of the class
		
		
*/		
		
/*new Trainer().briefInfo();
new Trainer().conductSessions();
*/

//Trainee t=new Trainee();


/*Trainee t1=new Trainee(99999,"Shuhbham",101,"s@gmail.com",4,"Pune","Maharastra","India");

//Trainee t2=new Trainee("Bangalore","Karnataka","India");

t1.printDetails();
*/

		Course c=new Course();
c.setCid(100);
c.setCname("Java");
c.setDuration(60);



System.out.println(c.getCname());
System.out.println(c.getDuration());

//c.printAll();

System.out.println(c.toString());// Object information

System.out.println(c.hashCode());// Object information


	
	}

}
