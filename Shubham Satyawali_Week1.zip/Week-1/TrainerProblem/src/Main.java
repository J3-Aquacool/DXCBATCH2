public class Main {

	public static void main(String[] args) {
		
		//array declaration and initialization
		Trainee[] arr = new Trainee[2]; 
		Course[] carr = new Course[2];
		Technology[] tarr = new Technology[1];
		Modules[] marr = new Modules[2];
		Units[] uarr = new Units[2];
		Topics[] toarr = new Topics[2];
		
		/* topics block */
		Topics to = new Topics();
		to.setvalue("Functional Interfaces", 2);
		//to.getvalue();
		System.out.println("");
		Topics to1 = new Topics();
		to1.setvalue("Empty Interfaces", 2);
		//to1.getvalue();
		toarr[0] = to;
		toarr[1] = to1;
		
		/* units block */
		Units u = new Units("Interfaces", 2, 103345);
		//System.out.println(u.toString());
		Units u1 = new Units("Abstract Classes", 3, 103346);
		//System.out.println(u1.toString());
		uarr[0] = u;
		uarr[1] = u1;
		u.printTopics(toarr);
		
		/* modules block */
		Modules m = new Modules("Inheritance", 4);
		//m.mdisplay(uarr);
		System.out.println("");
		Modules m1 = new Modules("Polymorphism", 5);
		//m1.mdisplay();
		marr[0] = m;
		marr[1] = m1;
		
		/* technology block */
		Technology tc = new Technology();
		tc.setTcname("J2EE");
		tc.setNumModules(10);
		//System.out.println(tc.getTcname());
		tarr[0] = tc;
		//tc.printMods(marr);
		
		/* course block */
		Course cr = new Course("Java", 101, "1st March 2021", 28, 3000);
		//cr.Display(tarr);
		carr[0] = cr; System.out.println("");
		Course cr1= new Course("SAP", 102, "2nd March 2021", 39, 3000);
		//cr1.Display(); System.out.println("");
		carr[1] = cr1;
				
		/* trainee block */
		Trainee tr = new Trainee("Shubham", 05, 21,"Java Development");
		//tr.printall(carr);
		arr[0]= tr;
		System.out.println("\n");
		Trainee tr1 = new Trainee("Ken", 03, 21, "Java Development");
		//tr1.printall(carr);
		arr[1] = tr1;
		
		  
		/* trainer block */
		Trainer t = new Trainer("Damien", 420, 38, 30);
		//t.display(arr);
		System.out.println("");
		
	}

}
