public class Triangles extends Shapes {
    private final double a, b, c; 

    public Triangles() {
        this(1,1,1);
    }
    public Triangles(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double area() {
       
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    @Override
    public double perimeter() {
        
        return a + b + c;
    }
}