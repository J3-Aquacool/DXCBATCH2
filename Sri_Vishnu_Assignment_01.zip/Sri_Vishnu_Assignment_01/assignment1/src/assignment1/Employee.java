package assignment1;

class Employee {

    int empid;
    String Name;
    String designation;
    double basic;
    double hra;

    int getEmpid() {
        return empid;
    }

    void setEmpid(int empid) {
        this.empid = empid;
    }

    String getName() {
        return Name;
    }

    void setName(String name) {
        Name = name;
    }

    String getDesignation() {
        return designation;
    }

    void setDesignation(String designation) {
        this.designation = designation;
    }


    void setBasic(double basic) {
        this.basic = basic;
    }

    public Employee(int empid, String name, String designation, double basic) {

        this.empid = empid;
        this.Name = name;
        this.designation = designation;
        this.basic = basic;
    }

    public void printDET() {
        System.out.println("Employee ID: " + empid);
        System.out.println("Employee Name: " + Name);
        System.out.println("Employee Designation: " + designation);
        System.out.println("Salary of Employee: " + basic);

    }

    public void calculateHRA() {
        if (designation == "Manager") {

            hra = basic * 0.1;
            System.out.println("HRA of Manager: " + hra);
        }

        else if (designation == "Officer") {

            hra = basic * 0.12;
            System.out.println("HRA of Officer: " + hra);
        }

        else if (designation == "Clerk"){

            hra = basic * 0.05;
            System.out.println("HRA of Clerk: " + hra);
        }

    }
    
    public void salaries() {
    	
        System.out.println("Salary of Employee "+empid+": "+basic);
        

    }
    
public void designations() {
    	
        System.out.println("Designation of Employee "+empid+": "+designation);
        

    }

    public static void main(String[] args) {
    	
    	System.out.println("EMPLOYEE DETAILS:");
        
        Employee e1 = new Employee(1, "Vishnu", "Manager", 50000);
        e1.printDET();
        e1.calculateHRA();
        
        System.out.println();
        Employee e2=new Employee(2,"Akhil","Officer",100000);
        e2.printDET();
        e2.calculateHRA();
        
        System.out.println();
        Employee e3=new Employee(3,"Anmol","Clerk",15000);
        e3.printDET();
        e3.calculateHRA();
        System.out.println();
        
        System.out.println("Displaying all salaries:");
        e1.salaries();
        e2.salaries();
        e3.salaries();
        System.out.println();
        
        System.out.println("Displaying all designations:");
        e1.designations();
        e2.designations();
        e3.designations();

    }

}
