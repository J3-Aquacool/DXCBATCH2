public class Circle extends Shape {

		 final double radius;
		final double pi=Math.PI;
		double area;
		
		public Circle(double radius) {
			
			this.radius = radius;
		}
		public void area() {
			
			if(radius<=0) {
				System.out.println("Invalid Input");
			}
			else {
			area=pi*(radius*radius);
			System.out.println("Area of the Circle is: "+area+unit);
		}
		}
		
}
