abstract class DXCCricketTeam     // DXCCricketTeam is a abstract class
{
	abstract public void Batsmen();                  
	abstract public void Bowlers();
	abstract public void Wicketkeepers();
	abstract public void Allrounders();
}
public class menTeam extends DXCCricketTeam    //menTeam IS A team of DXCCricketTeam
{
	


@Override
public void Batsmen() {
	
	
}

@Override
public void Bowlers() {
}

@Override
public void Wicketkeepers() {
	
}

@Override
public void Allrounders() {
	
	
}
}



public class womenTeam extends DXCCricketTeam   //womenTeam IS A team of DXCCricketTeam
{
	


@Override
public void Batsmen() {
	
	
}

@Override
public void Bowlers() {
}

@Override
public void Wicketkeepers() {
	
}

@Override
public void Allrounders() {
	
}
}

public class Cricket {
public static void main(String args[])
{
	DXCCricketTeam m= new menTeam(); //menTeam and WomenTeam are concrete class
	m.Batsmen();
        m.Bowlers();
        m.Wicketkeepers();
        m.Allrounders();

        DXCCricketTeam w= new womenTeam();
	w.Batsmen();
        w.Bowlers();
        w.Wicketkeepers();
        w.Allrounders();

}
}