 abstract class Shapes
{
    public abstract double Area();
}
 class Square extends Shapes
 {
	 double sideofsquare;
	 public Square(double sideofsquare)
	    {
	 
	        
	        //square constructor
	        this.sideofsquare = sideofsquare;
	    }
	 
	  public double Area() {
			  
		        return sideofsquare*sideofsquare;
		    }
	 
 }
class Circle_area extends Shapes
{ 
	double radiusofcircle;
	public Circle_area(double radiusofcircle)
    {
 
        
        //circle constructor called
        this.radiusofcircle = radiusofcircle;
    }
	
	 public double Area() {
		 
		 return Math.PI * Math.pow(radiusofcircle, 2);
	 }
}
class Triangle extends Shapes
{ double a,b,c;
  double s;
	public Triangle(double a,double b,double c)
	{
	    //triangle constructor called
	    this.a = a;
	    this.b=b;
	    this.c=c;
	}
  
	public double Area( ) {
		if (a< 0 || b < 0 || c < 0 || (a + b <= c) 
	            || a + c <= b || b + c <= a) 
	        {   
	            System.out.println("Not a valid input"); 
	        }
	        
	        	double s=(a+b+c)/2;
	        
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));
	}//we can even add new methods here further
}
public class AreaCalculation_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shapes s2 = new Square( 10);
		 Shapes s1 = new Circle_area(7);
	        //Shape s2 = new Square(  4);
	        Shapes s3=new Triangle(3,4,5);
	        //Shape s4=new Rectangle(2,4);
	 
	        System.out.println(s1.Area());
	        System.out.println(s2.Area());
	        System.out.println(s3.Area());
	       // System.out.println(s4.Area())
	        
	}

}

