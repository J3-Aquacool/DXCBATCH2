
public class EMP {

		int empid;
		String empName;
		String Designation;
		Double Basic;
		Double HRA;
		
	public EMP(int empid, String empName, String designation, Double basic) {
			super();
			this.empid = empid;
			this.empName = empName;
			Designation = designation;
			Basic = basic;
		}
	void HRA() {
		if(Designation=="Manager") {
			HRA=(Basic*0.10);
		}
		if(Designation=="Officer") {
			HRA=(Basic*0.12);
		}
		if(Designation=="Clerk") {
			HRA=(Basic*0.05);
		}
		System.out.println("HRA:"+HRA);
	}
	void printDET() {
		System.out.println("Name of the Employee: "+empName);
		System.out.println("Emp Id: "+empid);
		System.out.println("Designation: "+Designation);
		System.out.println("Basic Salary: "+Basic);
		System.out.println("HRA: "+HRA);
		System.out.println("Total Salary: "+(HRA+Basic));
		
}
}
