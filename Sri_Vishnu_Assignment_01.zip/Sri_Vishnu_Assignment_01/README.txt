This folder contains the following:

1) 'assignment1' is the Java Package which contains the programs to the given problem statements.

2) 'EmployeeDetailsIO' contains the text file which stores the employee details using IOPackage.

3) 'FileReaderAndWriter' contains the outputs of Reading & Writing to a file, i.e, 'demo.txt' and 'demo1.txt' files.

4) 'Question_2.txt' contains the skeletal structure of the "DXC_Cricket_Team", as given in the OOPs Assignment document.