package assignment1;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EmployeeIO {

    private String name,address;
    private float salary;
    private int age;

    public String getName()  {        
        return name;        
    }

    public float getSalary() {          
        return salary;     
    }
    
    public String getAddress(){
        return address;          
       }
    
    public int getAge() {
    	
    	return age;
    }

    public void setName(String name){
     this.name = name;          
    }

    public void setSalary(float salary){
        this.salary = salary;        
    } 

    public void setAddress(String address){
           this.address = address;        
       }
       
    public void setAge(int age){
           this.age = age;        
       }
       
    public static void main(String[] args) throws IOException {
    	
        EmployeeIO  emp = new EmployeeIO();
        
        emp.setName("Vishnu");
        emp.setAge(21);
        emp.setAddress("Dombivali East, Mumbai, Maharashtra, 421204");
        emp.setSalary(360000);
        System.out.println("Name: " + emp.getName());
        System.out.println("Age: " + emp.getAge());
        System.out.println("Address: " + emp.getAddress());
        System.out.println("Salary: " + emp.getSalary());
        
        //Writing employee details to a file
        
        String textName = "";
        int textAge;
        float textSalary;
        String textAddress = ""; 

        textName = emp.getName();
        textAge = emp.getAge();
        textSalary = emp.getSalary();
        textAddress = emp.getAddress();
        
        FileWriter empWrite = new FileWriter("C:/Users/psvis/Desktop/empDetails.txt",true);
        BufferedWriter bw = new BufferedWriter(empWrite);
        
        bw.write("Name of the employee: " + textName);
        bw.newLine();
        bw.write("Age of the employee: " + textAge);
        bw.newLine();
        bw.write("Address of the employee: " + textAddress);
        bw.newLine();
        bw.write("Salary of the employee: " + textSalary);
        bw.newLine();
        bw.write("----------------------------------------------------------------------------------------");
        bw.newLine();
        
        bw.close();
  
    }
}