import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIO {

	public static void main(String[] args) throws IOException
	{
		String str=" ";
		try {
		FileReader fr=new FileReader("C:\\Users\\Dell1\\OneDrive\\Desktop\\Y.txt");
		int i;
		while((i=fr.read())!=-1)
		{
			str=str+((char)i)+" ";
			System.out.print((char)i);
		}
		fr.close();

		
			
		FileWriter fw=new FileWriter("C:\\Users\\Dell1\\OneDrive\\Desktop\\Y1.txt",true);
		fw.write(str);
		System.out.print(str);
		fw.close();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
