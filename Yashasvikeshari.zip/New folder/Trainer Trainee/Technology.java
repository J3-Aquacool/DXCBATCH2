
public class Technology {
	String tname;
	String cname;
	int notrainee;
	int nomodules;
	String duration;
	
	 Technology(String tname,String cname,int nomodules,int notrainee,String duration)
	{ 	//this(notrainee,duration);
		this.tname=tname;
		this.cname=cname;
		this.nomodules=nomodules;
		this.notrainee=notrainee;
		this.duration=duration;
		
	}
	 Technology(int notrainee,String duration)
	{
		this.notrainee=notrainee;
		this.duration=duration;
		
	}
void printDetails()
{
	System.out.println("Technology name:"+tname);
	System.out.println("Technology course name:"+cname);
	System.out.println("Number of modules:"+nomodules);
	System.out.println("Number of trainee:"+notrainee);
	System.out.println("Duration:"+duration);
	}

}


public class MainApp
{
	public static void main(String args[])
	{
	Technology t=new Technology("Java8","Java",5,22,"28days");
		t.printDetails();
}
}