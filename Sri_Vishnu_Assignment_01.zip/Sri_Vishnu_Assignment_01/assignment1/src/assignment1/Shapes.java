package assignment1;

import java.util.Scanner;
import java.text.DecimalFormat;
interface triangle
{
    public void getAreas();
    public void showAreas();
}
interface square
{
    public void getAreas();
    public void showAreas();
} 
abstract class circle 
{
    public abstract void getAreas();
    public abstract void showAreas();
}
public class Shapes extends circle implements triangle,square
{
    Scanner scan = new Scanner(System.in);
    double carea,trarea,sqarea,r,b,s,h;
    DecimalFormat f = new DecimalFormat("##.00");
    public void getAreas()
    {
        System.out.println("Enter radius of circle (in meters): ");
        r=scan.nextFloat();
        System.out.println("Enter base of triangle (in meters): ");
        b=scan.nextFloat();
        System.out.println("Enter height of triangle (in meters): ");
        h=scan.nextFloat();
        System.out.println("Enter side of square (in meters): ");
        s=scan.nextFloat();
        
        System.out.println("Calculating areas of shapes...");
        System.out.println("");
        
        carea=3.14*r*r;       
        trarea=0.5*b*h;
        sqarea=s*s;
        
    }
    public void showAreas()
    {
        
            System.out.println("Area of circle: "+f.format(carea)+" square meters");
            System.out.println("Area of triangle: "+f.format(trarea)+" square meters");
            System.out.println("Area of square: "+f.format(sqarea)+" square meters");
            System.exit(0);
        }
    
    public static void main(String Args[])
    {
        Shapes xyz = new Shapes();
        xyz.getAreas();
        xyz.showAreas();
    }
}