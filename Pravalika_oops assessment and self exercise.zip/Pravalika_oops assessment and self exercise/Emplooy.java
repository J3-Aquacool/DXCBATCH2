public class Emplooy implements Serializable

{
	String Name;
	int Age;
	String Address;
	int Salary;
	Emplooy(String Name,int Age,String Address,int Salary)
	{
		setName(Name);
		setAge(Age);
		setAddress(Address);
		setSalary(Salary);
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = Name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		this.Age = Age;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		this.Address = Address;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		this.Salary = Salary;
	}
	@Override
	public String toString() {
		return "Employeee [name=" + Name + ", age=" + Age + ", address=" + Address + ", salary=" + Salary + "]";
	}
	
	

}