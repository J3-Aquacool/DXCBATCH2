public class Emp {
 int empId;
 String empName;
 String designation;
 double basic;
 double hra;
 double salary;
 Emp(String empName,int empId,String designation,double basic)
 {
	 this.empId=empId;
	 this.empName=empName;
	 this.designation=designation;
	 this.basic=basic;
 }
 double calculateHRA()
 {
	 if(designation=="Manager")
	 {
		hra=0.1*basic;
		System.out.println("House Rent Allowance:"+hra);
	 }else if(designation=="Officer")
	 {
	 hra=0.12*basic;
	 System.out.println("House Rent Allowance:"+hra);
	 }
	 else if(designation=="CLERK")
	 {
		 hra=0.05*basic;
		 System.out.println("House Rent Allowance:"+hra);
	 }
	 double salary=basic+hra;
	 System.out.println(" salary of employee:"+salary);
	 return salary;
 }

 ///void empbysalary()
// {
	
// }
// void empbydesg()
// {
	// if(EMP.S=="")
 //}
	 void printDET()
	 {
		 System.out.println("Name of Employee :"+empName);
		 System.out.println("Employee ID :"+empId);
		 System.out.println("Designation :"+designation);
		 System.out.println("Basic:"+basic);
		 //System.out.println("House Rent Allowance(HRA) :"+hra);
		 calculateHRA();
		
		 //calculateHRA();
		 
	 }
 
	public static void main(String[] args) {
		// TODO Auto-generated method 
		Emp Eobj=new Emp("Pravalika",169,"CLERK",20000);
		Eobj.printDET();
		//obj.calculateHRA();
	}

}

