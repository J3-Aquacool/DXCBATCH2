
public class Main {
public static void main(String[] args) {
	
	Topic t1 = new Topic("Inheritance","Abstraction","Encapsulation");
	Unit U1 = new Unit("Unit1",t1);
	Module M1= new Module("Module 1",U1);
	Course C1 = new Course("Java",101,50,M1);
	Trainee TT = new Trainee("Daniel","Daniel@gmail.com",1234,1,7238,C1);
	//U1.print();
	//M1.print();
	//TT.printDetails();
	Trainer T1 = new Trainer("Steve",7384,1231,"Steve@gmail.com",TT); 
	T1.printdetails();
}
}
