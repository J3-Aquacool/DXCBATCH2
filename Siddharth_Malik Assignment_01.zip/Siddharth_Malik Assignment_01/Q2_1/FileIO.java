import java.io.*;
class FileIO 
{ 
    public static void main(String[] args) throws IOException 
    { 
        int ch; 
        String strLine = "";
        String str_data = "";
        FileReader fr=new FileReader("/Users/harishmalik/Desktop/Input.txt"); 
        BufferedReader br = new BufferedReader(fr);
        while (strLine != null)
        {
           if (strLine == null)
             break;
           str_data += strLine;
           strLine = br.readLine();
           
       }
        //System.out.println(str_data);
        fr.close(); 
        // write to txt file
        FileWriter fw=new FileWriter("/Users/harishmalik/Desktop/Output.txt"); 
        
         
        for (int i = 0; i < str_data.length(); i++) 
            fw.write(str_data.charAt(i)); 
  
        System.out.println("Writing successful"); 
        fw.close();
    } 
} 