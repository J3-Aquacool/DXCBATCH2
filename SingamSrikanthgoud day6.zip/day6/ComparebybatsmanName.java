

	import java.util.Comparator;

	public class ComparebybatsmanName implements Comparator<Cricketer> 
	{

		
		@Override
		public int compare(Cricketer o1, Cricketer o2) {
			return o1.getBatsmanName().compareTo(o2.getBatsmanName());
			
		}
		
		}




