public class Technology {
	protected String tcname;
	private int numModules;
	
	public String getTcname() {
		return tcname;
	}
	public void setTcname(String tcname) {
		this.tcname = tcname;
	}
	public int getNumModules() {
		return numModules;
	}
	public void setNumModules(int numModules) {
		this.numModules = numModules;
	}
	public void printMods(Modules[] marr) {
		System.out.print(tcname+" has modules like: ");
		for(Modules m: marr) {
			System.out.print(m.mName+" ");
		}
	}
}
