import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
public class Persist {
	public static void main(String[] args)throws IOException,ClassNotFoundException  
	{
        emp1 e = new emp1(); 
       
        e.printDET();
       
        
        FileOutputStream fos = new FileOutputStream("C:\\Users\\Dell1\\OneDrive\\Desktop\\New folder\\Q2_2\\Output.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(e.toString());
			System.out.println("Done");
			oos.close();
			fos.close();
}

}