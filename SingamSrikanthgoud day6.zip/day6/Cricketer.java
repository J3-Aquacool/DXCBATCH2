
public  class Cricketer /*implements Comparable< Cricketer > */{
	String batsmanName;
	public Cricketer(String batsmanName,int battingPosition) {
		super();
		this.batsmanName = batsmanName;
		this.battingPosition = battingPosition;
	}
	public String getBatsmanName() {
		return batsmanName;
	}
	public void setBatsmanName(String batsmanName) {
		this.batsmanName = batsmanName;
	}
	public  int getBattingPosition() {
		return battingPosition;
	}
	public void setBattingPosition(int battingPosition) {
		this.battingPosition = battingPosition;
	}
	private int battingPosition;
	@Override
	public String toString() {
		return "Cricketer [batsmanName=" + batsmanName + ", battingPosition=" + battingPosition + "]";
	}
	/*@Override
	/*public int compareTo(Cricketer o) {
		// TODO Auto-generated method stub
		
		return this.battingPosition.compareTo(o.battingPosition);
	}*/
	
	

}
