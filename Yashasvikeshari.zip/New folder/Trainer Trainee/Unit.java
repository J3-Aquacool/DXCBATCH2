
public class Unit {
	Unit()
	{}
	String uname;
	int notopic;
	String duration;
	
	Unit(String uname,int notopic,String duration)
	{this.uname=uname;
	this.notopic=notopic;
	this.duration=duration;
	}
public String toString()
{
	return uname+" "+notopic+" "+duration;
	}
}




public class MainApp
{
	public static void main(String args[])
	{
		Unit u=new Unit("Inheritance",6,"4days");
		System.out.println(u.toString());
	
}
}