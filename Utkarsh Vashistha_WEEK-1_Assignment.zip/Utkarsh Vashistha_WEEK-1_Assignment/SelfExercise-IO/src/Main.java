import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br = null;
		BufferedWriter bw = null;
		try {
			String currLine;
			br = new BufferedReader(new FileReader("/home/utkarsh/Development/Java/IOSelfExercise/src/demo.txt"));
			bw = new BufferedWriter(new FileWriter("/home/utkarsh/Development/Java/IOSelfExercise/src/demo1.txt"));

			/*
			 * do { currLine = br.readLine(); System.out.println(currLine);
			 * }while(br.readLine() != null);
			 */
			while ((currLine = br.readLine()) != null) {
			
				System.out.println(currLine);
				bw.write(currLine+"\n");
			}
			 
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			br.close();
			bw.close();
		}
	}
		
}


