
public class Square extends Shape {

	
		final double side;
		double area;
		public Square(double side) {
			this.side = side;
		}
		
		public void area() {
			if(side<=0) {
				System.out.println("Invalid Input");
			}
			else {
			area=side*side;
			System.out.println("Area of the Square is: "+area+unit);
		}
		}
		
}
