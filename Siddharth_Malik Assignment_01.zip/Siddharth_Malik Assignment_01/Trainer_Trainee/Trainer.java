
public class Trainer {

	
	private String name;
	private int trid;
	private int phone;
	private String emailid;
	Trainee T;

		




public Trainer(String name, int trid, int phone, String emailid,Trainee T) {
		super();
		this.name = name;
		this.trid = trid;
		this.phone = phone;
		this.emailid = emailid;
		this.T=T;
	}



void printdetails() {
	System.out.println("Trainer Name:"+name);
	System.out.println("Trainer Id:"+trid);
	System.out.println("Trainer email"+emailid);
	System.out.println("Trainer Phone:"+phone);
	System.out.println("Trainee Details Are: "+"\n"+T.print());
}

}