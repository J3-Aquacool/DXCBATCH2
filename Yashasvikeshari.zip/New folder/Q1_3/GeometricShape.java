
 public abstract class Shapes {
    public abstract double area();
    public abstract double perimeter();
}
public class GeometricShape {
	public static void main(String args[])
	{
		double width = 5;
        Shapes square = new Square(width);
        System.out.println("Square width: " + width
                + "\nResulting area: " + square.area()+"sq units"
                + "\nResulting perimeter: " + square.perimeter() +"units"+ "\n");

        
        double radius = 5;
        Shapes circle = new Circles(radius);
        System.out.println("Circle radius: " + radius
            + "\nResulting Area: " + circle.area() +"sq units"
            + "\nResulting Perimeter: " + circle.perimeter() +"units"+ "\n");

        
        double a = 5, b = 3, c = 4;
        Shapes triangle = new Triangles(a,b,c);
        System.out.println("Triangle sides lengths: " + a + ", " + b + ", " + c
                + "\nResulting Area: " + triangle.area() +"sq units"
                + "\nResulting Perimeter: " + triangle.perimeter() +"units"+ "\n");
	}

}
