
public class Assignment {
	public static void main(String[] args) {
        Emp e = new Emp(); 
       
        e.printDET();
        System.out.println();
        Emp e1 = new Emp(2, "Yashasvi", "Manager", 90000);
        e1.printDET();
       
        System.out.println();
        Emp e2=new Emp(3,"Rohan","officer",70000);
        e2.printDET();
        
        System.out.println();
        Emp e3=new Emp(4,"Abhinav","cleark",12000);
        e3.printDET();
        

    }




}
