
public class Demo
{
/*static
{
	
	System.out.println("Static block");
}*/

// No-Name block
	
	
{
	System.out.println("No-Name block");
	
}
	
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		
		System.out.println("Static method");
	}

}
