
public class Trainee {

	
	private String name;
	private String emailid;
	private int phoneno;
	private int totalnocourse;
	private int id;
	Course C;
	

	public Trainee(String name, String emailid, int phoneno, int totalnocourse, int id, Course c) {
		super();
		this.name = name;
		this.emailid = emailid;
		this.phoneno = phoneno;
		this.totalnocourse = totalnocourse;
		this.id = id;
		C = c;
	}






	void printDetails() 
	{
			System.out.println("Name:" +name);
			System.out.println("Email id: "+emailid);
			System.out.println("Phone no.: "+phoneno);
			System.out.println("Trainee id: "+id);
			System.out.println("Enrolled no of courses: "+totalnocourse);
			System.out.println(C.print());
		
	}
	String print() {
		return "Trainee Name:" +name+"\n"+"Trainee Email id: "+emailid+"\n"+"Trainee Phone no.: "+phoneno+"\n"+"Trainee id: "+id+"\n"+"Enrolled no of courses: "+totalnocourse+"\n"+C.print();
	}
}
	
