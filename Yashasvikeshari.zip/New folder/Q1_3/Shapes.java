
 public abstract class Shapes {
    public abstract double area();
    public abstract double perimeter();
}