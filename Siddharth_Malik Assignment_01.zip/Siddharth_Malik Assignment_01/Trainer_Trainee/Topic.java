
public class Topic {

	public String Topic1;
	public String Topic2;
	public String Topic3;
	
	
	Topic(){
		
	}
	
	public Topic(String topic1, String topic2, String topic3) {
		super();
		Topic1 = topic1;
		Topic2 = topic2;
		Topic3 = topic3;
	}
	String print() {
		//System.out.println();
		return "Topics are : 1)"+Topic1+" 2) "+Topic2+" 3) "+Topic3;
	}
	void printDetails() {
		System.out.println("Topics are : 1)"+Topic1+" 2) "+Topic2+" 3) "+Topic3);
	}

	@Override
	public String toString() {
		return "Topic [Topic1=" + Topic1 + ", Topic2=" + Topic2 + ", Topic3=" + Topic3 + "]";
	}
}
