public class Trainee 
{
int phoneno;
String name;
int id;
String emailid;
int totalnocourse;
String city,state,country;

Trainee(int phoneno,String name,int id,String emailid,int totalnocourse,String city,String state,String country)
{
	
	this(city,state,country);
	// Comiple is Facing ambiguity
	this.phoneno=phoneno;
	this.name=name;
	this.id=id;
	this.emailid=emailid;
	this.totalnocourse=totalnocourse;
	this.city=city;
	this.state=state;
	this.country=country;
	}
Trainee(String city,String state,String country)
{
this.city=city;
this.state=state;
this.country=country;

}


void printDetails()
{
System.out.println("Name:"+name);
System.out.println("Phoen Number:"+phoneno);
System.out.println("Traineee Id:"+id);
System.out.println("Email Id:"+emailid);
System.out.println("Enrolled No Of Courses:"+totalnocourse);

System.out.println("City:"+city);
	System.out.println("State:"+state);
	System.out.println("Country:"+country);
}

}

