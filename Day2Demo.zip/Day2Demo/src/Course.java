
public class Course 

{
private	String cname;

	 private int cid;
	private int duration;

	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	Course()
	{
		
		
	}
public Course(String cname, int cid, int duration) 
{
		this.cname = cname;
		this.cid = cid;
		this.duration = duration;
}

public void printAll()
{
	
/*	System.out.println(cname);
	System.out.println(cid);
	System.out.println(duration);
	*
	*/
	String output=cname+cid+duration;
	System.out.println(output);
}



// Overiden method of Object Class

/*public String toString()
{
	
	return cname + "  "+cid +"  "+ duration;
			
}
*/





}

