
public class Main {
	public static void main(String[] args) {
		EMP[] arr = new EMP[3];
		
		EMP e = new EMP(101, "Utkarsh Vashistha", " Senior Manager", 35000);
		e.printDET();
		arr[0] = e;
		
		EMP e1 = new EMP(102, "Abraham", "Clerk", 25000);
		//e1.printDET();
		arr[1] = e1;
		
		EMP e2 = new EMP(103, "Shivam", "Officer", 45000);
		//e2.printDET();
		arr[2] = e2;
		
		
		GetEmployees g = new GetEmployees();
		g.getByDes(arr, "Officer");
		g.getBySalary(arr, 25000);
		 
	}
}
