public class Course1 
{
	Course1()
	{}
private String cname;
private int cid;
private int duration;
public Course1(String cname,int cid,int duration)
{
	this.cname=cname;
	this.cid=cid;
	this.duration=duration;
}
public void printAll() 
{/*System.out.println("Course name:"+cname);
System.out.println("Course id:"+cid);
System.out.println("Course duration:"+duration);
*/
	String output=cname+cid+duration;
	System.out.println(output);
	}
public String toString() 
{return cname+" "+cid+" "+duration;
}

public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}

/*public void setName(String name)
{}
public String getName()
{return cname;
}*/
}


public class MainApp
{
	public static void main(String args[])
	{
	Course1 ob=new Course1();
		System.out.println(ob.toString());
}
}