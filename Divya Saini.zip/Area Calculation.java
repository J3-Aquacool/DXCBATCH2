
package GeometricAreaCalculation;

public class GeometricAreaCalculation 
{
    public static void main(String[] args) 
    {
        Square s = new Square();
        Circle c = new Circle();
        Triangle t = new Triangle();
        
        s.getValues();
        s.calculateArea();
        s.showArea();
        
        c.getValues();
        c.calculateArea();
        c.showArea();
        
        t.getValues();
        t.calculateArea();
        t.showArea();
    }
}
