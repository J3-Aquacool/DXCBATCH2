
public class GetEmployees {

	public void getByDes(EMP[] arr, String Des){
		System.out.println("Getting employees with designation = "+Des);
		for (EMP t: arr) {
			if(t.DESIGNATION == Des) {
				System.out.println("Employee found");
				System.out.println(t.EMPNAME+"\n");
			}
		}
	}
	public void getBySalary(EMP[] arr,double Bas){
		System.out.println("Getting employees with basic salary= "+Bas);
		for (EMP t: arr) {
			if(t.BASIC == Bas) {
				System.out.println("Employee found");
				System.out.println(t.EMPNAME+"\n");
			}
		}
	}		
}

