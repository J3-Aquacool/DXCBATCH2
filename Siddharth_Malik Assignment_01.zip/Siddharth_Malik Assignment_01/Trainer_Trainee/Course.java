
public class Course {

		String cname;
		int cid;
		int duration;
		Module M;
		 

		public Course(String cname, int cid, int duration, Module m) {
			super();
			this.cname = cname;
			this.cid = cid;
			this.duration = duration;
			M = m;
		}


		void printdetails() {
			System.out.println("Course Name: "+cname);
			System.out.println("Course Id: "+cid);
			System.out.println("Duration of the Course: "+duration+"");
			System.out.println("Modules Are : "+"\n"+M.print());
		}
		String print() {
			return "Course Name: "+cname+"\n"+"Course Id:"+cid+"\n"+" Duration of the Course :"+duration+" Hours"+"\n"+"\n"+M.print();
		}
		public String toString() {
			return "Course1 [cname=" + cname + ", cid=" + cid + ", duration=" + duration + "]";
		}
		
		 
}
