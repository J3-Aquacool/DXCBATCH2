public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Shape s = new Square(5);
		Shape c = new Circle(7);
		Shape t = new Triangle(4, 4);
		double sarea = s.calcArea();
		double carea = c.calcArea();
		double tarea = t.calcArea();
		
		System.out.println("Area of Square: "+sarea+"\n\nArea of Circle: "+carea+"\n\nArea of Triangle: "+tarea);
	}

}
