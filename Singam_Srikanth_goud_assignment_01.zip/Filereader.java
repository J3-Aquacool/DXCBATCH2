
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Filereader {
		 public static void main(String args[]) {
			 try {
		 File obj =new File("dxc.txt");
		
		 FileWriter fiw=new FileWriter(obj);
		 FileReader fir=new FileReader(obj);
		 String name="jagadish ";
		 fiw.write(name);
		 fiw.close(); 
		 System.out.println("File writing successfully");
		 int i;    
         while((i=fir.read())!=-1)    
         System.out.print((char)i);    
         fir.close();
			 }
			 catch (Exception e)
			 {
				 System.out.println(e.getMessage());
			 }

}
}
