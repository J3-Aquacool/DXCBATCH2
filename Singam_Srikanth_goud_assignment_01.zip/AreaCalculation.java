
 abstract class Shape
{
    public abstract double Area();
}
 class square extends Shape
 {
	 double side;
	 public square(double side)
	    {
	 
	        
	        //System.out.println("square constructor called");
	        this.side = side;
	    }
	 
	  public double Area() {
			  
		        return side*side;
		    }
	 
 }
class circle extends Shape
{ 
	double radius;
	public circle(double radius)
    {
 
        
        //System.out.println("circle constructor called");
        this.radius = radius;
    }
	
	 public double Area() {
		 
		 return Math.PI * Math.pow(radius, 2);
	 }
}
class triangle extends Shape
{ double a,b,c;
  double s;
	public triangle(double a,double b,double c)
	{
	    //System.out.println("triangle constructor called");
	    this.a = a;
	    this.b=b;
	    this.c=c;
	}
  
	public double Area( ) {
		if (a< 0 || b < 0 || c < 0 || (a + b <= c) 
	            || a + c <= b || b + c <= a) 
	        {   
	            System.out.println("Not a valid input"); 
	        }
	        
	        	double s=(a+b+c)/2;
	        
		return Math.sqrt(s*(s-a)*(s-b)*(s-c));
	}
}
public class AreaCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Shape s1 = new circle( 2.2);
	        Shape s2 = new square(  4);
	        Shape s3=new triangle(2,5,3);
	 
	        System.out.println(s1.Area());
	        System.out.println(s2.Area());
	        System.out.println(s3.Area());
	}

}
