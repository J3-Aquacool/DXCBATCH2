public class Course {
	protected String cname;
	private int cID;
	private String cStartDt;
	private int cduration; //in days
	private int price;
	
	Course(String cname, int cID, String cStartDt, int cduration, int price){
		this(cStartDt, cduration, price);												//constructor chaining
		this.cname = cname;
		this.cID = cID;
		
	}
	
	Course(String cStartDt, int cduration, int price){
		this(price);
		this.cStartDt = cStartDt;
		this.cduration = cduration;
	}
	
	Course(int price){
		this.price = price;
	}

	void Display(Technology[] tarr){
		System.out.println("Course name: "+cname);
		System.out.println("Course ID: "+cID);
		System.out.println("Starting Date: "+cStartDt);
		System.out.println("Duration(in days): "+cduration);
		System.out.println("Price: "+price+ " rupees.");
		System.out.print(cname+" has technology/ies like: ");
		for (Technology t : tarr) {
			System.out.print(t.tcname + " ");
		}
	}
}
