
public abstract class Shape {

	void  area() {
		
	}
	String unit=" cm";
}